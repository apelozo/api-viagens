import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm';
import { TransportSeat } from '../../transport-seat/entities/transport-seat.entity';

@Entity('transporte')
export class Transport {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'viagem_id', type: 'uuid' })
  viagemId: string;

  @Column({ name: 'tipo', type: 'enum', enum: ['voo', 'trem', 'onibus', 'carro'] })
  type: 'voo' | 'trem' | 'onibus' | 'carro';

  @Column({ name: 'companhia', type: 'varchar', length: 255, nullable: true })
  company: string;

  @Column({ name: 'numero_identificacao', type: 'varchar', length: 100, nullable: true })
  identificationNumber: string;

  @Column({ name: 'local_partida', type: 'varchar', length: 255, nullable: true })
  departureLocation: string;

  @Column({ name: 'local_chegada', type: 'varchar', length: 255, nullable: true })
  arrivalLocation: string;

  @Column({ name: 'data_partida', type: 'timestamp', nullable: true })
  departureDate: Date;

  @Column({ name: 'data_chegada', type: 'timestamp', nullable: true })
  arrivalDate: Date;

  @Column({ name: 'valor_pago', type: 'decimal', precision: 10, scale: 2, nullable: true })
  amountPaid: number;

  @Column({ name: 'metodo_pagamento', type: 'enum', enum: ['dinheiro', 'cartao', 'transferencia'], nullable: true })
  paymentMethod: 'dinheiro' | 'cartao' | 'transferencia';

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Novo relacionamento adicionado para conectar com a tabela transporte_assento:
  @OneToMany(() => TransportSeat, (seat) => seat.transport)
  seats: TransportSeat[];
}