import { IsUUID, IsEnum, IsOptional, IsDateString, IsNumber, IsString } from 'class-validator';

/**
 * DTO para criação de um novo Transporte.
 * Valida os dados de entrada da requisição HTTP.
 * REMOVIDOS: originCityId e destinationCityId.
 */
export class CreateTransportDto {
  // O ID da viagem é obrigatório para criar um transporte
  @IsUUID()
  viagemId: string;

  @IsEnum(['voo', 'trem_onibus', 'carro'])
  tipo: 'voo' | 'trem_onibus' | 'carro';

  // O ID do roteiro é opcional
  @IsOptional()
  @IsUUID()
  roteiroId?: string;

  @IsOptional()
  @IsDateString()
  dataPartida?: string;

  @IsOptional()
  @IsDateString()
  dataChegada?: string;

  @IsOptional()
  @IsNumber()
  valorPago?: number;

  @IsOptional()
  @IsEnum(['dinheiro', 'cartao', 'transferencia'])
  metodoPagamento?: 'dinheiro' | 'cartao' | 'transferencia';
}