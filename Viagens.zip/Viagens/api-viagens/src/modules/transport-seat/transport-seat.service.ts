import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateTransportSeatDto } from './dto/create-transport-seat.dto';
import { UpdateTransportSeatDto } from './dto/update-transport-seat.dto';
import { TransportSeat } from './entities/transport-seat.entity';

@Injectable()
export class TransportSeatService {
  constructor(
    @InjectRepository(TransportSeat)
    private readonly transportSeatRepository: Repository<TransportSeat>,
  ) {}

  async create(createTransportSeatDto: CreateTransportSeatDto): Promise<TransportSeat> {
    const seat = this.transportSeatRepository.create(createTransportSeatDto);
    return await this.transportSeatRepository.save(seat);
  }

  async findAll(): Promise<TransportSeat[]> {
    return await this.transportSeatRepository.find({ relations: ['transport'] });
  }

  async findOne(id: string): Promise<TransportSeat> {
    const seat = await this.transportSeatRepository.findOne({ 
      where: { id },
      relations: ['transport']
    });
    if (!seat) {
      throw new NotFoundException(`TransportSeat with ID ${id} not found`);
    }
    return seat;
  }

  async findByTransport(transportId: string): Promise<TransportSeat[]> {
    return await this.transportSeatRepository.find({ where: { transportId } });
  }

  async update(id: string, updateTransportSeatDto: UpdateTransportSeatDto): Promise<TransportSeat> {
    const seat = await this.findOne(id);
    this.transportSeatRepository.merge(seat, updateTransportSeatDto);
    return await this.transportSeatRepository.save(seat);
  }

  async remove(id: string): Promise<void> {
    const result = await this.transportSeatRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException(`TransportSeat with ID ${id} not found`);
    }
  }
}