import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Transport } from '../../transport/entities/transport.entity';

@Entity('transporte_assento')
export class TransportSeat {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'transporte_id', type: 'uuid' })
  transportId: string;

  @Column({ name: 'numero_assento', type: 'varchar', length: 10, nullable: true })
  seatNumber: string;

  @Column({ name: 'classe', type: 'varchar', nullable: true }) // Mapeado como varchar para aceitar o enum do banco
  seatClass: string;

  @Column({ name: 'valor_pago', type: 'decimal', precision: 10, scale: 2, nullable: true })
  amountPaid: number;

  @Column({ name: 'metodo_pagamento', type: 'varchar', nullable: true }) // Mapeado como varchar para aceitar o enum do banco
  paymentMethod: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @ManyToOne(() => Transport, (transport) => transport.seats, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'transporte_id' })
  transport: Transport;
}