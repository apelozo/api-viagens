import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { TransportSeatService } from './transport-seat.service';
import { CreateTransportSeatDto } from './dto/create-transport-seat.dto';
import { UpdateTransportSeatDto } from './dto/update-transport-seat.dto';

@Controller('transport-seat')
export class TransportSeatController {
  constructor(private readonly transportSeatService: TransportSeatService) {}

  @Post()
  async create(@Body() createTransportSeatDto: CreateTransportSeatDto) {
    return await this.transportSeatService.create(createTransportSeatDto);
  }

  @Get()
  async findAll() {
    return await this.transportSeatService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return await this.transportSeatService.findOne(id);
  }

  @Get('transport/:transportId')
  async findByTransport(@Param('transportId') transportId: string) {
    return await this.transportSeatService.findByTransport(transportId);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateTransportSeatDto: UpdateTransportSeatDto) {
    return await this.transportSeatService.update(id, updateTransportSeatDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    return await this.transportSeatService.remove(id);
  }
}