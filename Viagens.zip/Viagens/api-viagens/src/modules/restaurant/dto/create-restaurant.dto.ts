import { IsString, IsNotEmpty, IsUUID, IsNumber, IsOptional, IsEnum } from 'class-validator';

export class CreateRestaurantDto {
  @IsUUID()
  @IsNotEmpty()
  cityId: string;

  @IsString()
  @IsNotEmpty()
  name: string;

  @IsOptional()
  @IsNumber()
  amountPaid?: number;

  @IsOptional()
  @IsEnum(['dinheiro', 'cartao', 'transferencia'])
  paymentMethod?: 'dinheiro' | 'cartao' | 'transferencia';
}