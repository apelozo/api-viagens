import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateTravelDto } from './dto/create-travel.dto';
import { UpdateTravelDto } from './dto/update-travel.dto';
import { Travel } from './entities/travel.entity';

@Injectable()
export class TravelService {
  constructor(
    @InjectRepository(Travel)
    private readonly travelRepository: Repository<Travel>,
  ) {}

  async create(createTravelDto: CreateTravelDto): Promise<Travel> {
    const travel = this.travelRepository.create(createTravelDto);
    return await this.travelRepository.save(travel);
  }

  async findAll(): Promise<Travel[]> {
    return await this.travelRepository.find({ relations: ['cities'] });
  }

  async findOne(id: string): Promise<Travel> {
    const travel = await this.travelRepository.findOne({ 
      where: { id },
      relations: ['cities'] 
    });
    if (!travel) {
      throw new NotFoundException(`Travel with ID ${id} not found`);
    }
    return travel;
  }

  async update(id: string, updateTravelDto: UpdateTravelDto): Promise<Travel> {
    const travel = await this.findOne(id);
    this.travelRepository.merge(travel, updateTravelDto);
    return await this.travelRepository.save(travel);
  }

  async remove(id: string): Promise<void> {
    const result = await this.travelRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException(`Travel with ID ${id} not found`);
    }
  }
}