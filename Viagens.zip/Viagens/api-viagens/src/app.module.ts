import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';

// Importando todos os nossos módulos
import { TravelModule } from './modules/travel/travel.module';
import { CityModule } from './modules/city/city.module';
import { HotelModule } from './modules/hotel/hotel.module';
import { RestaurantModule } from './modules/restaurant/restaurant.module';
import { TourModule } from './modules/tour/tour.module';
import { RouteModule } from './modules/route/route.module';
import { TransportModule } from './modules/transport/transport.module';
import { TransportSeatModule } from './modules/transport-seat/transport-seat.module';
import { ObservationModule } from './modules/observation/observation.module';

@Module({
  imports: [
    // Configuração para ler o arquivo .env
    ConfigModule.forRoot({ isGlobal: true }),
    
    // Configuração do Banco de Dados PostgreSQL
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
	  port: parseInt(process.env.DB_PORT || '5432', 10),
      username: process.env.DB_USERNAME || 'postgres', // Mude se o seu usuário for diferente
      password: process.env.DB_PASSWORD || 'Sistemas', // Mude para a sua senha
      database: process.env.DB_DATABASE || 'viagens_db', // Mude para o nome do seu banco
      autoLoadEntities: true,
      synchronize: false, // Mantemos false porque seu banco já existe
    }),
    
    // Nossos Módulos
    TravelModule,
    CityModule,
    HotelModule,
    RestaurantModule,
    TourModule,
    RouteModule,
    TransportModule,
    TransportSeatModule,
    ObservationModule,
  ],
})
export class AppModule {}